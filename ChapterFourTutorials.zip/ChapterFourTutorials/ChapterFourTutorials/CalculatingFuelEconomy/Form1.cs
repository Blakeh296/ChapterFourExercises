﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatingFuelEconomy
{
    public partial class F1CalculatingFuelEconomy : Form
    {
        public F1CalculatingFuelEconomy()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double miles; // To hold miles driven
            double gallons; // To hold gallons used
            double mpg; //to hold MPG

            // Validate the miles text box
            if (double.TryParse(textBox1.Text, out miles))
            {
                // Validate the Gallons text box
                if (double.TryParse(textBox2.Text, out gallons))
                {
                    // Calculate MPG
                    mpg = miles / gallons;

                    // display the MPG to the output label
                    outPutLabel.Text = mpg.ToString("0.00") + " MPG";
                }
                else
                {
                    // Display an error message for gallons text box
                    MessageBox.Show("Invalid input for gallons.");
                }
            }
            else
            {
                // display an error message for miles textbox
                MessageBox.Show("Invalid input for miles");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            outPutLabel.Text = " ";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
