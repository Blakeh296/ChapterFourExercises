﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PayrollWithOvertime
{
    public partial class f1PayrollWithOvertime : Form
    {
        public f1PayrollWithOvertime()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Named Constants
            const decimal BASE_HOURS = 40m;
            const decimal OT_MULTIPLIER = 1.5m;

            // Local variables
            decimal hoursWorked;
            decimal hourlyPayRate;
            decimal basePay;
            decimal overtimeHours;
            decimal overtimePay;
            decimal grossPay;

            try
            {
                // Get the hours worked and hourly pay rate.
                hoursWorked = decimal.Parse(textBox1.Text);
                hourlyPayRate = decimal.Parse(textBox2.Text);

                // Determine the gross pay
                if (hoursWorked > BASE_HOURS)
                {
                    // Calculate the base pay (without Overtime)
                    basePay = hourlyPayRate * BASE_HOURS;

                    // Calculate the number of overtime hours
                    overtimeHours = hoursWorked - BASE_HOURS;

                    // Calculate overtime pay
                    overtimePay = overtimeHours * hourlyPayRate * OT_MULTIPLIER;

                    // Calculate the gross pay
                    grossPay = basePay + overtimePay;
                }
                else
                {
                    // Calculate the gross pay
                    grossPay = hoursWorked * hourlyPayRate;
                }
                // Display the gross pay
                outPutLabel.Text = grossPay.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            outPutLabel.Text = " ";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
