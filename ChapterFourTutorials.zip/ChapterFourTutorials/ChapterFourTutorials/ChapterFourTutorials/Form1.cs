﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChapterFourTutorials
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            const double HIGH_SCORE = 95.0; // High Score Value
            double test1;
            double test2;
            double test3;
            double average;

            try
            {
                // Get the test scores from the Text Boxes
                test1 = double.Parse(textBox1.Text);
                test2 = double.Parse(textBox2.Text);
                test3 = double.Parse(textBox3.Text);

                // Calculating the average test score
                average = (test1 + test2 + test3) / 3.0;

                outPutLabel.Text = average.ToString("0.00");

                //If the average is a high score, congragulate the user
                if (average > HIGH_SCORE)
                {
                    MessageBox.Show("Congragulations! New High Score!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            outPutLabel.Text = " ";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
