﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanQualifier
{
    public partial class F1LoanQualifier : Form
    {
        public F1LoanQualifier()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Name constants
            const decimal MINIMUM_SALARY = 40000m;
            const int MINIMUM_YEARS_ON_JOB = 2;

            // Local variables
            decimal salary;
            int yearsOnJob;
            try
            {
                // Get the salary and years on the job
                salary = decimal.Parse(textBox1.Text);
                yearsOnJob = int.Parse(textBox2.Text);

                // Determine whether the user qualifies
                if (salary >= MINIMUM_SALARY)
                {
                    if (yearsOnJob >= MINIMUM_YEARS_ON_JOB)
                    {
                        // The user qualifies
                        outPutLabel.Text = "You qualify for the loan!";
                    }
                    else
                    {
                        // The user does not qualify
                        outPutLabel.Text = "user does not meet work requirments";
                    }
                }
                else
                {
                    outPutLabel.Text = "user does not meet salary requirments";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            outPutLabel.Text = " ";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
